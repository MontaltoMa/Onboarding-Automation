#!/bin/bash

zip -r "onboardingAutomation.zip" * -x "onboardingAutomation.zip"